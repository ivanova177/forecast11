package com.example.retrofitforecaster

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.retrofitforecaster.MyCustomApplication.Companion.api1
import com.example.retrofitforecaster.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    companion object {
        const val API_KEY = "4e583f9f8b55a87429c1c4590d09fa7e"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val adapter = WeatherAdapter()
        with(binding.rView) {
            this.adapter = adapter
            this.layoutManager = LinearLayoutManager(this@MainActivity)
            addItemDecoration(DividerItemDecoration(
                this@MainActivity, DividerItemDecoration.VERTICAL)
            )
        }

        GlobalScope.launch {
            //val items = forecastApiService.getHourlyForecastForNextDays("Shklov", API_KEY)
            val items = api1.getHourlyForecastForNextDays("Shklov", API_KEY)
            withContext(Dispatchers.Main) {
                adapter.submitList(items.list)
            }
        }
    }

}